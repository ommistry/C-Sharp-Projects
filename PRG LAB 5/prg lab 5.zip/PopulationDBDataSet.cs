﻿namespace PRG_LAB_5
{


    partial class PopulationDBDataSet
    {
    }
}

